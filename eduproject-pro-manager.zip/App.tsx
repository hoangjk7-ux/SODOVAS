
import React, { useState, useEffect } from 'react';
import { ViewType, Department, Personnel, Project } from './types';
import { INITIAL_DEPARTMENTS, INITIAL_PERSONNEL, INITIAL_PROJECTS } from './constants';
import ProjectList from './components/ProjectList';
import DiagramView from './components/DiagramView';
import ConfigView from './components/ConfigView';
import { getProjectAnalysis } from './services/geminiService';

const App: React.FC = () => {
  const [view, setView] = useState<ViewType>('list');
  const [departments, setDepartments] = useState<Department[]>(INITIAL_DEPARTMENTS);
  const [personnel, setPersonnel] = useState<Personnel[]>(INITIAL_PERSONNEL);
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [aiSummary, setAiSummary] = useState<string>("Đang tải phân tích dữ liệu...");

  useEffect(() => {
    const fetchAnalysis = async () => {
      const summary = await getProjectAnalysis(projects, departments, personnel);
      setAiSummary(summary);
    };
    fetchAnalysis();
  }, [projects, departments, personnel]);

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50">
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-72 bg-white border-r border-slate-200 p-6 flex flex-col sticky top-0 h-screen overflow-y-auto z-50">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white">
            <i className="fa-solid fa-graduation-cap text-xl"></i>
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-tight text-slate-900 leading-none">EduManager</h1>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Project Pro</span>
          </div>
        </div>

        <nav className="flex-1 space-y-1">
          <NavItem 
            active={view === 'list'} 
            onClick={() => setView('list')} 
            icon="fa-list-check" 
            label="Danh sách dự án" 
          />
          <NavItem 
            active={view === 'diagram'} 
            onClick={() => setView('diagram')} 
            icon="fa-sitemap" 
            label="Sơ đồ tổ chức" 
          />
          <NavItem 
            active={view === 'config'} 
            onClick={() => setView('config')} 
            icon="fa-gear" 
            label="Cấu hình hệ thống" 
          />
        </nav>

        <div className="mt-auto p-4 bg-blue-50 rounded-2xl border border-blue-100">
          <div className="flex items-center gap-2 mb-2">
            <i className="fa-solid fa-brain text-blue-600"></i>
            <span className="text-xs font-bold text-blue-800 uppercase tracking-tight">AI Insights</span>
          </div>
          <p className="text-[11px] leading-relaxed text-blue-600/80">
            {aiSummary}
          </p>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 md:p-8 lg:p-12 max-w-7xl mx-auto w-full">
        <header className="mb-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">
              {view === 'list' && "Quản lý Dự án"}
              {view === 'diagram' && "Sơ đồ Chiến lược"}
              {view === 'config' && "Trung tâm Cấu hình"}
            </h2>
            <p className="text-slate-500 mt-1">
              {view === 'list' && "Theo dõi và phân bổ đầu mối dự án hiệu quả."}
              {view === 'diagram' && "Góc nhìn tổng quan về cấu trúc phòng ban và dự án."}
              {view === 'config' && "Tùy chỉnh dữ liệu nền tảng cho tổ chức."}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex flex-col items-end">
              <span className="text-sm font-bold text-slate-900">Quản lý Phát triển</span>
              <span className="text-xs text-slate-400">Giám đốc Dự án</span>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-slate-200 overflow-hidden border-2 border-white shadow-sm">
              <img src="https://picsum.photos/id/64/100/100" alt="Avatar" />
            </div>
          </div>
        </header>

        {/* Dynamic Content */}
        <section className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          {view === 'list' && (
            <ProjectList 
              projects={projects} 
              departments={departments} 
              personnel={personnel} 
            />
          )}
          {view === 'diagram' && (
            <DiagramView 
              departments={departments} 
              projects={projects} 
              personnel={personnel} 
            />
          )}
          {view === 'config' && (
            <ConfigView 
              departments={departments} 
              personnel={personnel} 
              projects={projects}
              setDepartments={setDepartments}
              setPersonnel={setPersonnel}
              setProjects={setProjects}
            />
          )}
        </section>
      </main>
    </div>
  );
};

const NavItem: React.FC<{ active: boolean, onClick: () => void, icon: string, label: string }> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
      active 
        ? 'bg-blue-600 text-white shadow-lg shadow-blue-200 font-semibold' 
        : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900'
    }`}
  >
    <i className={`fa-solid ${icon} text-lg w-6 ${active ? 'text-white' : 'text-slate-400 group-hover:text-blue-500'}`}></i>
    <span>{label}</span>
  </button>
);

export default App;
