
import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { Department, Project, Personnel } from '../types';
import { STATUS_COLORS } from '../constants';

interface DiagramViewProps {
  departments: Department[];
  projects: Project[];
  personnel: Personnel[];
}

const DiagramView: React.FC<DiagramViewProps> = ({ departments, projects, personnel }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [hoveredProject, setHoveredProject] = useState<{ project: Project; x: number; y: number } | null>(null);

  // Constants for base sizing
  const NODE_WIDTH = 300;
  const MIN_NODE_HEIGHT = 120;
  const PROJECT_ROW_HEIGHT = 32;
  const HEADER_HEIGHT = 50;
  const FOOTER_HEIGHT = 30;
  const VERTICAL_GAP = 120;
  const HORIZONTAL_GAP = 100;

  const getNodeHeight = (projectCount: number) => {
    const calculatedHeight = HEADER_HEIGHT + (projectCount * PROJECT_ROW_HEIGHT) + FOOTER_HEIGHT;
    return Math.max(MIN_NODE_HEIGHT, calculatedHeight);
  };

  useEffect(() => {
    if (!svgRef.current || departments.length === 0) return;

    // Clear previous
    d3.select(svgRef.current).selectAll("*").remove();

    try {
      // Create hierarchy data for departments
      const stratify = d3.stratify<Department>()
        .id(d => d.id)
        .parentId(d => d.parentId);

      const root = stratify(departments);

      // Calculate max height to ensure layout doesn't overlap
      const maxProjects = d3.max(departments, d => projects.filter(p => p.departmentId === d.id).length) || 0;
      const maxPossibleHeight = getNodeHeight(maxProjects);

      // Calculate tree layout
      const treeLayout = d3.tree()
        .nodeSize([NODE_WIDTH + HORIZONTAL_GAP, maxPossibleHeight + VERTICAL_GAP]);
      
      const treeData = treeLayout(root);

      const svg = d3.select(svgRef.current);
      const g = svg.append("g");

      // Zoom behavior
      const zoom = d3.zoom<SVGSVGElement, unknown>()
        .scaleExtent([0.1, 2])
        .on("zoom", (event) => g.attr("transform", event.transform));

      svg.call(zoom as any);

      // Initial positioning
      svg.call(zoom.transform as any, d3.zoomIdentity.translate(window.innerWidth / 3, 100).scale(0.7));

      // Links: Orthogonal/Step paths
      g.selectAll(".link")
        .data(treeData.links())
        .enter()
        .append("path")
        .attr("class", "orthogonal-path")
        .attr("d", (d: any) => {
          const sourceHeight = getNodeHeight(projects.filter(p => p.departmentId === d.source.data.id).length);
          const targetHeight = getNodeHeight(projects.filter(p => p.departmentId === d.target.data.id).length);
          
          const startX = d.source.x;
          const startY = d.source.y + sourceHeight / 2;
          const endX = d.target.x;
          const endY = d.target.y - targetHeight / 2;
          const midY = (startY + endY) / 2;

          return `M${startX},${startY} 
                  L${startX},${midY} 
                  L${endX},${midY} 
                  L${endX},${endY}`;
        });

      // Nodes
      const node = g.selectAll(".node")
        .data(treeData.descendants())
        .enter()
        .append("g")
        .attr("transform", (d: any) => `translate(${d.x},${d.y})`);

      // Draw individual nodes
      node.each(function(d: any) {
        const nodeGroup = d3.select(this);
        const deptProjects = projects.filter(p => p.departmentId === d.data.id);
        const h = getNodeHeight(deptProjects.length);

        // 1. Shadow/Accent Background (Box-in-Box effect)
        nodeGroup.append("rect")
          .attr("x", -NODE_WIDTH / 2 - 6)
          .attr("y", -h / 2 - 6)
          .attr("width", NODE_WIDTH)
          .attr("height", h)
          .attr("rx", 16)
          .attr("fill", d.data.color)
          .attr("opacity", 0.1);

        // 2. Main Content Box
        nodeGroup.append("rect")
          .attr("x", -NODE_WIDTH / 2)
          .attr("y", -h / 2)
          .attr("width", NODE_WIDTH)
          .attr("height", h)
          .attr("rx", 12)
          .attr("fill", "white")
          .attr("stroke", d.data.color)
          .attr("stroke-width", 2)
          .attr("class", "shadow-sm");

        // 3. Department Name Header
        nodeGroup.append("text")
          .attr("y", -h / 2 + 28)
          .attr("text-anchor", "middle")
          .attr("class", "font-bold text-slate-800 pointer-events-none")
          .style("font-size", "15px")
          .text(d.data.name);

        // 4. Projects Sub-boxes with Hover functionality
        const projectG = nodeGroup.append("g")
          .attr("transform", `translate(0, ${-h / 2 + 45})`);

        deptProjects.forEach((proj, i) => {
          const projBoxY = i * PROJECT_ROW_HEIGHT;
          
          const row = projectG.append("g")
            .attr("class", "cursor-help transition-all hover:translate-x-1")
            .on("mouseenter", (event) => {
              setHoveredProject({ project: proj, x: event.pageX, y: event.pageY });
            })
            .on("mousemove", (event) => {
              setHoveredProject(prev => prev ? { ...prev, x: event.pageX, y: event.pageY } : null);
            })
            .on("mouseleave", () => {
              setHoveredProject(null);
            });

          row.append("rect")
            .attr("x", -NODE_WIDTH / 2 + 12)
            .attr("y", projBoxY)
            .attr("width", NODE_WIDTH - 24)
            .attr("height", 26)
            .attr("rx", 6)
            .attr("fill", "#f8fafc")
            .attr("stroke", "#e2e8f0");

          row.append("text")
            .attr("x", -NODE_WIDTH / 2 + 20)
            .attr("y", projBoxY + 17)
            .style("font-size", "11px")
            .attr("class", "fill-slate-600 font-medium pointer-events-none")
            .text(proj.name.length > 35 ? proj.name.substring(0, 35) + "..." : proj.name);
        });

        // 5. Personnel Count in Footer
        const deptPersonnel = personnel.filter(p => p.departmentId === d.data.id);
        nodeGroup.append("text")
          .attr("y", h / 2 - 12)
          .attr("text-anchor", "middle")
          .style("font-size", "11px")
          .attr("class", "fill-slate-400 font-semibold pointer-events-none")
          .text(`👥 ${deptPersonnel.length} nhân sự`);
      });
    } catch (e) {
      console.error("D3 Hierarchy Error:", e);
      d3.select(svgRef.current).append("text")
        .attr("x", 20)
        .attr("y", 40)
        .text("Lỗi cấu trúc sơ đồ. Vui lòng kiểm tra lại quan hệ cha-con trong phần Cấu hình.");
    }

  }, [departments, projects, personnel]);

  return (
    <div className="w-full h-[750px] bg-slate-50 rounded-2xl shadow-inner border border-slate-200 overflow-hidden relative">
      <div className="absolute top-4 left-4 z-10">
        <div className="bg-white/90 backdrop-blur px-4 py-3 rounded-xl border border-slate-200 shadow-sm text-xs text-slate-500 flex items-center gap-6">
          <div className="flex flex-col gap-1">
            <span className="font-bold text-slate-700 uppercase tracking-tight">Chú thích</span>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500 opacity-20 border border-blue-500"></div>
                <span>Phòng ban</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded bg-slate-100 border border-slate-300"></div>
                <span>Dự án (Rê chuột xem chi tiết)</span>
              </div>
            </div>
          </div>
          <div className="h-8 w-px bg-slate-200"></div>
          <div className="flex flex-col gap-1">
            <span className="font-medium text-slate-400">Điều khiển</span>
            <span className="text-slate-600">Cuộn để phóng to • Kéo để di chuyển</span>
          </div>
        </div>
      </div>

      <svg ref={svgRef} className="w-full h-full cursor-grab active:cursor-grabbing"></svg>

      {/* Custom Tooltip for Project Details */}
      {hoveredProject && (
        <div 
          className="fixed z-[999] pointer-events-none bg-white border border-slate-200 shadow-xl rounded-xl p-4 w-72 animate-in fade-in zoom-in duration-150"
          style={{ left: hoveredProject.x + 20, top: hoveredProject.y - 40 }}
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Thông tin dự án</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${STATUS_COLORS[hoveredProject.project.status]}`}>
              {hoveredProject.project.status}
            </span>
          </div>
          <h4 className="font-bold text-slate-900 leading-tight mb-2">{hoveredProject.project.name}</h4>
          <p className="text-xs text-slate-500 mb-3 line-clamp-3 italic">"{hoveredProject.project.description}"</p>
          
          <div className="space-y-2 border-t border-slate-100 pt-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center text-[10px] font-bold text-blue-600">
                <i className="fa-solid fa-user-tie"></i>
              </div>
              <div>
                <div className="text-[10px] text-slate-400 leading-none">Phụ trách chính</div>
                <div className="text-xs font-semibold text-slate-700">
                  {personnel.find(p => p.id === hoveredProject.project.leadId)?.name || 'Chưa xác định'}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-emerald-50 flex items-center justify-center text-[10px] font-bold text-emerald-600">
                <i className="fa-solid fa-calendar"></i>
              </div>
              <div>
                <div className="text-[10px] text-slate-400 leading-none">Ngày bắt đầu</div>
                <div className="text-xs font-semibold text-slate-700">{hoveredProject.project.startDate}</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DiagramView;
