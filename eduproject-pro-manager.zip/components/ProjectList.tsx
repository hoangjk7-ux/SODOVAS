
import React, { useState, useMemo } from 'react';
import { Project, ProjectStatus, Department, Personnel } from '../types';
import { STATUS_COLORS } from '../constants';

interface ProjectListProps {
  projects: Project[];
  departments: Department[];
  personnel: Personnel[];
}

const ProjectList: React.FC<ProjectListProps> = ({ projects, departments, personnel }) => {
  const [statusFilter, setStatusFilter] = useState<ProjectStatus | 'all'>('all');
  const [deptFilter, setDeptFilter] = useState<string | 'all'>('all');
  const [personnelFilter, setPersonnelFilter] = useState<string | 'all'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
      const matchesDept = deptFilter === 'all' || p.departmentId === deptFilter;
      const matchesPersonnel = personnelFilter === 'all' || p.leadId === personnelFilter;
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesStatus && matchesDept && matchesPersonnel && matchesSearch;
    });
  }, [projects, statusFilter, deptFilter, personnelFilter, searchTerm]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-4 items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200">
        <div className="flex-1 min-w-[200px]">
          <div className="relative">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
              <i className="fa-solid fa-magnifying-glass"></i>
            </span>
            <input
              type="text"
              placeholder="Tìm kiếm dự án..."
              className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <select
          className="px-4 py-2 border border-slate-200 rounded-lg bg-white outline-none focus:ring-2 focus:ring-blue-500 text-sm"
          value={deptFilter}
          onChange={(e) => setDeptFilter(e.target.value)}
        >
          <option value="all">Tất cả phòng ban</option>
          {departments.map(d => (
            <option key={d.id} value={d.id}>{d.name}</option>
          ))}
        </select>

        <select
          className="px-4 py-2 border border-slate-200 rounded-lg bg-white outline-none focus:ring-2 focus:ring-blue-500 text-sm"
          value={personnelFilter}
          onChange={(e) => setPersonnelFilter(e.target.value)}
        >
          <option value="all">Tất cả nhân sự</option>
          {personnel.map(p => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>

        <select
          className="px-4 py-2 border border-slate-200 rounded-lg bg-white outline-none focus:ring-2 focus:ring-blue-500 text-sm"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as any)}
        >
          <option value="all">Tất cả trạng thái</option>
          {Object.values(ProjectStatus).map(s => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      <div className="overflow-x-auto bg-white rounded-xl shadow-sm border border-slate-200">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-4 font-semibold text-slate-600">Dự án</th>
              <th className="px-6 py-4 font-semibold text-slate-600">Phòng ban</th>
              <th className="px-6 py-4 font-semibold text-slate-600">Đầu mối chính</th>
              <th className="px-6 py-4 font-semibold text-slate-600">Ngày bắt đầu</th>
              <th className="px-6 py-4 font-semibold text-slate-600">Trạng thái</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredProjects.length > 0 ? filteredProjects.map(p => {
              const dept = departments.find(d => d.id === p.departmentId);
              const lead = personnel.find(pers => pers.id === p.leadId);
              return (
                <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-medium text-slate-900">{p.name}</div>
                    <div className="text-sm text-slate-500 truncate max-w-xs">{p.description}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 rounded text-xs font-medium" style={{ backgroundColor: `${dept?.color}20`, color: dept?.color }}>
                      {dept?.name || 'N/A'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-700">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600 uppercase">
                        {lead?.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-sm font-medium">{lead?.name || 'N/A'}</div>
                        <div className="text-xs text-slate-400">{lead?.role}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-500 text-sm">
                    {p.startDate}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${STATUS_COLORS[p.status]}`}>
                      {p.status}
                    </span>
                  </td>
                </tr>
              );
            }) : (
              <tr>
                <td colSpan={5} className="px-6 py-10 text-center text-slate-400">
                  Không tìm thấy dự án nào phù hợp.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProjectList;
