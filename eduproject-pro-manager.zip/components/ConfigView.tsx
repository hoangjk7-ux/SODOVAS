
import React, { useState } from 'react';
import { Department, Personnel, Project, ProjectStatus } from '../types';

interface ConfigViewProps {
  departments: Department[];
  personnel: Personnel[];
  projects: Project[];
  setDepartments: React.Dispatch<React.SetStateAction<Department[]>>;
  setPersonnel: React.Dispatch<React.SetStateAction<Personnel[]>>;
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
}

type EditingState = {
  type: 'dept' | 'person' | 'proj';
  item: any;
} | null;

const ConfigView: React.FC<ConfigViewProps> = ({ 
  departments, personnel, projects, 
  setDepartments, setPersonnel, setProjects 
}) => {
  const [activeTab, setActiveTab] = useState<'dept' | 'person' | 'proj'>('dept');
  const [editing, setEditing] = useState<EditingState>(null);

  const handleDelete = (type: string, id: string) => {
    if (!window.confirm("Bạn có chắc chắn muốn xóa mục này?")) return;
    
    if (type === 'dept') setDepartments(prev => prev.filter(d => d.id !== id));
    if (type === 'person') setPersonnel(prev => prev.filter(p => p.id !== id));
    if (type === 'proj') setProjects(prev => prev.filter(p => p.id !== id));
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing) return;

    const { type, item } = editing;

    if (type === 'dept') {
      setDepartments(prev => {
        const exists = prev.some(d => d.id === item.id);
        return exists ? prev.map(d => d.id === item.id ? item : d) : [...prev, item];
      });
    } else if (type === 'person') {
      setPersonnel(prev => {
        const exists = prev.some(p => p.id === item.id);
        return exists ? prev.map(p => p.id === item.id ? item : p) : [...prev, item];
      });
    } else if (type === 'proj') {
      setProjects(prev => {
        const exists = prev.some(p => p.id === item.id);
        return exists ? prev.map(p => p.id === item.id ? item : p) : [...prev, item];
      });
    }

    setEditing(null);
  };

  const startAdd = (type: 'dept' | 'person' | 'proj') => {
    if (type === 'dept') {
      setEditing({
        type,
        item: { id: `dept-${Date.now()}`, name: '', parentId: null, color: '#3b82f6' }
      });
    } else if (type === 'person') {
      setEditing({
        type,
        item: { id: `p-${Date.now()}`, name: '', departmentId: departments[0]?.id || '', role: '', parentId: null, email: '' }
      });
    } else if (type === 'proj') {
      setEditing({
        type,
        item: { id: `proj-${Date.now()}`, name: '', departmentId: departments[0]?.id || '', leadId: personnel[0]?.id || '', status: ProjectStatus.PLANNED, description: '', startDate: new Date().toISOString().split('T')[0] }
      });
    }
  };

  // Helper to check if we are creating a new item vs editing
  const isNew = editing && !([...departments, ...personnel, ...projects].some(x => x.id === editing.item.id));

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden relative">
      {/* Modal / Overlay for Editing */}
      {editing && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="font-bold text-slate-800">
                {isNew ? 'Thêm mới' : 'Chỉnh sửa'} {editing.type === 'dept' ? 'Phòng ban' : editing.type === 'person' ? 'Nhân sự' : 'Dự án'}
              </h3>
              <button onClick={() => setEditing(null)} className="text-slate-400 hover:text-slate-600">
                <i className="fa-solid fa-xmark text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSaveEdit} className="p-6 space-y-4">
              {editing.type === 'dept' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tên phòng ban</label>
                    <input 
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      value={editing.item.name}
                      onChange={e => setEditing({...editing, item: {...editing.item, name: e.target.value}})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Phòng ban cấp trên</label>
                    <select 
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none"
                      value={editing.item.parentId || ''}
                      onChange={e => setEditing({...editing, item: {...editing.item, parentId: e.target.value || null}})}
                    >
                      <option value="">Không có (Cấp cao nhất)</option>
                      {departments.filter(d => d.id !== editing.item.id).map(d => (
                        <option key={d.id} value={d.id}>{d.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Màu sắc định danh</label>
                    <input 
                      type="color"
                      className="w-full h-10 p-1 border border-slate-200 rounded-lg outline-none cursor-pointer"
                      value={editing.item.color}
                      onChange={e => setEditing({...editing, item: {...editing.item, color: e.target.value}})}
                    />
                  </div>
                </>
              )}

              {editing.type === 'person' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Họ và tên</label>
                    <input 
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      value={editing.item.name}
                      onChange={e => setEditing({...editing, item: {...editing.item, name: e.target.value}})}
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Chức vụ</label>
                      <input 
                        className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none"
                        value={editing.item.role}
                        onChange={e => setEditing({...editing, item: {...editing.item, role: e.target.value}})}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Phòng ban</label>
                      <select 
                        className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none"
                        value={editing.item.departmentId}
                        onChange={e => setEditing({...editing, item: {...editing.item, departmentId: e.target.value}})}
                      >
                        {departments.map(d => (
                          <option key={d.id} value={d.id}>{d.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email</label>
                    <input 
                      type="email"
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none"
                      value={editing.item.email}
                      onChange={e => setEditing({...editing, item: {...editing.item, email: e.target.value}})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Người quản lý trực tiếp</label>
                    <select 
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none"
                      value={editing.item.parentId || ''}
                      onChange={e => setEditing({...editing, item: {...editing.item, parentId: e.target.value || null}})}
                    >
                      <option value="">Không có</option>
                      {personnel.filter(p => p.id !== editing.item.id).map(p => (
                        <option key={p.id} value={p.id}>{p.name} ({p.role})</option>
                      ))}
                    </select>
                  </div>
                </>
              )}

              {editing.type === 'proj' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tên dự án</label>
                    <input 
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      value={editing.item.name}
                      onChange={e => setEditing({...editing, item: {...editing.item, name: e.target.value}})}
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Phòng ban phụ trách</label>
                      <select 
                        className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none"
                        value={editing.item.departmentId}
                        onChange={e => setEditing({...editing, item: {...editing.item, departmentId: e.target.value}})}
                      >
                        {departments.map(d => (
                          <option key={d.id} value={d.id}>{d.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Trạng thái</label>
                      <select 
                        className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none"
                        value={editing.item.status}
                        onChange={e => setEditing({...editing, item: {...editing.item, status: e.target.value as ProjectStatus}})}
                      >
                        {Object.values(ProjectStatus).map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Đầu mối làm việc chính</label>
                    <select 
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none"
                      value={editing.item.leadId}
                      onChange={e => setEditing({...editing, item: {...editing.item, leadId: e.target.value}})}
                    >
                      {personnel.map(p => (
                        <option key={p.id} value={p.id}>{p.name} ({departments.find(d => d.id === p.departmentId)?.name})</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mô tả dự án</label>
                    <textarea 
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none h-24 resize-none"
                      value={editing.item.description}
                      onChange={e => setEditing({...editing, item: {...editing.item, description: e.target.value}})}
                    />
                  </div>
                </>
              )}

              <div className="flex gap-3 pt-4">
                <button 
                  type="button"
                  onClick={() => setEditing(null)}
                  className="flex-1 px-4 py-2 border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  Hủy bỏ
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-bold"
                >
                  {isNew ? 'Thêm mới' : 'Lưu thay đổi'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="flex border-b border-slate-200 bg-slate-50/50">
        <button 
          onClick={() => setActiveTab('dept')}
          className={`px-6 py-4 font-medium text-sm transition-colors ${activeTab === 'dept' ? 'border-b-2 border-blue-600 text-blue-600 bg-white' : 'text-slate-500 hover:text-slate-700'}`}
        >
          Phòng Ban
        </button>
        <button 
          onClick={() => setActiveTab('person')}
          className={`px-6 py-4 font-medium text-sm transition-colors ${activeTab === 'person' ? 'border-b-2 border-blue-600 text-blue-600 bg-white' : 'text-slate-500 hover:text-slate-700'}`}
        >
          Nhân Sự
        </button>
        <button 
          onClick={() => setActiveTab('proj')}
          className={`px-6 py-4 font-medium text-sm transition-colors ${activeTab === 'proj' ? 'border-b-2 border-blue-600 text-blue-600 bg-white' : 'text-slate-500 hover:text-slate-700'}`}
        >
          Dự Án
        </button>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-slate-800">
            {activeTab === 'dept' ? 'Quản lý Phòng Ban' : activeTab === 'person' ? 'Quản lý Nhân sự' : 'Quản lý Dự án'}
          </h2>
          <button 
            onClick={() => startAdd(activeTab)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <i className="fa-solid fa-plus"></i>
            Thêm mới
          </button>
        </div>

        <div className="space-y-3">
          {activeTab === 'dept' && departments.map(d => (
            <div key={d.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100 group">
              <div className="flex items-center gap-3">
                <div className="w-4 h-4 rounded shadow-sm" style={{ backgroundColor: d.color }}></div>
                <span className="font-medium text-slate-700">{d.name}</span>
                {d.parentId && <span className="text-xs text-slate-400 bg-slate-200/50 px-2 py-0.5 rounded">Trực thuộc: {departments.find(p => p.id === d.parentId)?.name}</span>}
              </div>
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setEditing({ type: 'dept', item: d })}
                  className="opacity-0 group-hover:opacity-100 p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-all"
                >
                  <i className="fa-solid fa-pen-to-square"></i>
                </button>
                <button 
                  onClick={() => handleDelete('dept', d.id)}
                  className="opacity-0 group-hover:opacity-100 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                >
                  <i className="fa-solid fa-trash-can"></i>
                </button>
              </div>
            </div>
          ))}

          {activeTab === 'person' && personnel.map(p => (
            <div key={p.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100 group">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-white border border-slate-200 rounded-full flex items-center justify-center text-blue-600 font-bold shadow-sm">
                  {p.name.charAt(0)}
                </div>
                <div>
                  <div className="font-medium text-slate-700">{p.name}</div>
                  <div className="text-xs text-slate-400">{p.role} • {departments.find(d => d.id === p.departmentId)?.name}</div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setEditing({ type: 'person', item: p })}
                  className="opacity-0 group-hover:opacity-100 p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-all"
                >
                  <i className="fa-solid fa-pen-to-square"></i>
                </button>
                <button 
                  onClick={() => handleDelete('person', p.id)}
                  className="opacity-0 group-hover:opacity-100 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                >
                  <i className="fa-solid fa-trash-can"></i>
                </button>
              </div>
            </div>
          ))}

          {activeTab === 'proj' && projects.map(proj => (
            <div key={proj.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100 group">
              <div>
                <div className="font-medium text-slate-700">{proj.name}</div>
                <div className="text-xs text-slate-400">Trạng thái: <span className="font-semibold text-blue-600">{proj.status}</span> • Phụ trách: {personnel.find(p => p.id === proj.leadId)?.name}</div>
              </div>
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setEditing({ type: 'proj', item: proj })}
                  className="opacity-0 group-hover:opacity-100 p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-all"
                >
                  <i className="fa-solid fa-pen-to-square"></i>
                </button>
                <button 
                  onClick={() => handleDelete('proj', proj.id)}
                  className="opacity-0 group-hover:opacity-100 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                >
                  <i className="fa-solid fa-trash-can"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ConfigView;
