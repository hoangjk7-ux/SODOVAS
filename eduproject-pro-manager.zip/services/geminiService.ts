
import { GoogleGenAI } from "@google/genai";
import { Project, Department, Personnel } from "../types";

export const getProjectAnalysis = async (projects: Project[], depts: Department[], personnel: Personnel[]) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    const dataContext = `
      Projects: ${JSON.stringify(projects)}
      Departments: ${JSON.stringify(depts)}
      Personnel: ${JSON.stringify(personnel)}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Phân tích dữ liệu dự án giáo dục sau và đưa ra một đoạn tóm tắt ngắn gọn (3-4 câu) về tình hình phân bổ nhân sự và tiến độ. Dữ liệu: ${dataContext}`,
      config: {
        systemInstruction: "Bạn là một chuyên gia quản lý dự án giáo dục. Hãy đưa ra nhận xét chuyên nghiệp, súc tích bằng tiếng Việt.",
      }
    });

    return response.text || "Không thể tải phân tích lúc này.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Hãy cấu hình API Key để nhận phân tích thông minh.";
  }
};
