
import { ProjectStatus, Department, Personnel, Project } from './types';

export const INITIAL_DEPARTMENTS: Department[] = [
  { id: 'dept-1', name: 'Ban Giám Hiệu', parentId: null, color: '#3b82f6' },
  { id: 'dept-2', name: 'Phòng Đào Tạo', parentId: 'dept-1', color: '#10b981' },
  { id: 'dept-3', name: 'Phòng Công Nghệ', parentId: 'dept-1', color: '#8b5cf6' },
  { id: 'dept-4', name: 'Phòng Truyền Thông', parentId: 'dept-1', color: '#f59e0b' },
  { id: 'dept-5', name: 'Tổ Chuyên Môn Toán', parentId: 'dept-2', color: '#ec4899' },
];

export const INITIAL_PERSONNEL: Personnel[] = [
  { id: 'p-1', name: 'Nguyễn Văn A', departmentId: 'dept-1', role: 'Giám đốc', parentId: null, email: 'a@edu.vn' },
  { id: 'p-2', name: 'Trần Thị B', departmentId: 'dept-2', role: 'Trưởng phòng', parentId: 'p-1', email: 'b@edu.vn' },
  { id: 'p-3', name: 'Lê Văn C', departmentId: 'dept-3', role: 'Trưởng phòng', parentId: 'p-1', email: 'c@edu.vn' },
  { id: 'p-4', name: 'Phạm Minh D', departmentId: 'dept-2', role: 'Giảng viên', parentId: 'p-2', email: 'd@edu.vn' },
  { id: 'p-5', name: 'Hoàng Lan E', departmentId: 'dept-3', role: 'Kỹ sư hệ thống', parentId: 'p-3', email: 'e@edu.vn' },
];

export const INITIAL_PROJECTS: Project[] = [
  { 
    id: 'proj-1', 
    name: 'Số hóa học liệu 2024', 
    departmentId: 'dept-2', 
    leadId: 'p-2', 
    status: ProjectStatus.IN_PROGRESS, 
    description: 'Chuyển đổi toàn bộ tài liệu giấy sang định dạng số.',
    startDate: '2024-01-15'
  },
  { 
    id: 'proj-2', 
    name: 'Nâng cấp LMS', 
    departmentId: 'dept-3', 
    leadId: 'p-3', 
    status: ProjectStatus.PLANNED, 
    description: 'Nâng cấp hệ thống quản lý học tập lên phiên bản 3.0.',
    startDate: '2024-03-01'
  },
  { 
    id: 'proj-3', 
    name: 'Chiến dịch tuyển sinh Hè', 
    departmentId: 'dept-4', 
    leadId: 'p-1', 
    status: ProjectStatus.IN_PROGRESS, 
    description: 'Thu hút 500 học sinh mới cho kỳ nhập học tháng 9.',
    startDate: '2024-04-10'
  },
  { 
    id: 'proj-4', 
    name: 'Xây dựng ngân hàng câu hỏi Toán', 
    departmentId: 'dept-5', 
    leadId: 'p-4', 
    status: ProjectStatus.COMPLETED, 
    description: 'Hoàn thiện 5000 câu hỏi trắc nghiệm Toán cấp THPT.',
    startDate: '2023-11-01'
  }
];

export const STATUS_COLORS = {
  [ProjectStatus.PLANNED]: 'bg-blue-100 text-blue-700 border-blue-200',
  [ProjectStatus.IN_PROGRESS]: 'bg-amber-100 text-amber-700 border-amber-200',
  [ProjectStatus.COMPLETED]: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  [ProjectStatus.ON_HOLD]: 'bg-slate-100 text-slate-700 border-slate-200',
};
