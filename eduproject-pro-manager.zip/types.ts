
export enum ProjectStatus {
  PLANNED = 'Planned',
  IN_PROGRESS = 'In Progress',
  COMPLETED = 'Completed',
  ON_HOLD = 'On Hold'
}

export interface Department {
  id: string;
  name: string;
  parentId: string | null;
  color: string;
}

export interface Personnel {
  id: string;
  name: string;
  departmentId: string;
  role: string;
  parentId: string | null; // Hierarchy within personnel
  email: string;
}

export interface Project {
  id: string;
  name: string;
  departmentId: string;
  leadId: string; // ID of the personnel in charge
  status: ProjectStatus;
  description: string;
  startDate: string;
}

export type ViewType = 'dashboard' | 'list' | 'diagram' | 'config';

export interface HierarchyNode<T> {
  data: T;
  children: HierarchyNode<T>[];
}
